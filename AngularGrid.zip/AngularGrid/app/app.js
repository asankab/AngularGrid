var app = angular.module('app', ['ui.grid', 'ui.grid.selection',  'ui.grid.pagination', 'ngStorage']);

app.controller('MainCtrl', ['$scope', '$http', '$log', '$localStorage', '$timeout' , function ($scope, $http, $log, $localStorage, $timeout) {

  var data1 = {
    "statusCode": 200,
    "data": [
      {
        "file": "file1.csv",
        "createdDate": "2016-09-26T07:38:13.382Z"
      },
      {
        "file": "file2.csv",
        "createdDate": "2016-09-26T07:38:29.898Z"
      },
      {
        "file": "file3.csv",
        "createdDate": "2016-09-26T07:50:43.836Z"
      },
      {
        "file": "file4.csv",
        "createdDate": "2016-09-26T07:38:13.382Z"
      },
      {
        "file": "file5.csv",
        "createdDate": "2016-09-26T07:55:29.898Z"
      },
      {
        "file": "file6.csv",
        "createdDate": "2016-09-26T07:50:43.836Z"
      },
      {
        "file": "file7.csv",
        "createdDate": "2016-09-26T07:38:13.382Z"
      },
      {
        "file": "file8.csv",
        "createdDate": "2016-10-26T07:38:29.898Z"
      },
      {
        "file": "file9.csv",
        "createdDate": "2016-09-26T07:50:43.836Z"
      }
      ,
      {
        "file": "file10.csv",
        "createdDate": "2016-09-26T07:50:43.836Z"
      }
      ,
      {
        "file": "file11.csv",
        "createdDate": "2016-09-26T07:50:43.836Z"
      }
      ,
      {
        "file": "file12.csv",
        "createdDate": "2016-09-26T07:50:43.836Z"
      }
    ],
    "error": null
  };

  //data1 = null;

  $scope.gridOptions = {
    enableSorting: false,
    enablePaging  : true,
    enableFiltering: true,
    paginationPageSizes: [25, 50, 75],
    paginationPageSize: 10,
    enableRowSelection: true,
    enableSelectAll: true,
    selectionRowHeaderWidth: 35,
    filterOptions: $scope.filterOptions
  };

  $scope.gridOptions.columnDefs = [
    { name: 'file', displayName: 'File Name'/*, width: 400*/ },
    { name: 'createdDate', displayName: 'Created Date', type: 'date', cellFilter: 'date:\'short\'', enableFiltering : false, sort: { direction: 'desc' }/*, width: 200*/ },
    { name: 'Navigate to Test Page', displayName: '',  cellTemplate: '<button class="btn primary" ng-click="grid.appScope.navigateToTestPage(row)">Navigate to Test Page</button>', width: 160, enableHiding: false, showHeader: false, enableFiltering: false  },
    { name: 'Delete', displayName: '',  cellTemplate: '<button class="btn primary" ng-click="grid.appScope.deleteRow(row)">Delete</button>', width: 70, enableHiding: false, showHeader: false, enableFiltering: false }
  ];

  $scope.gridOptions.multiSelect = false;

  $http.get('https://cdn.rawgit.com/angular-ui/ui-grid.info/gh-pages/data/500_complex.json')
      .success(function(data) {
        $scope.gridOptions.data = data1.data;

        $timeout(function () {
          $scope.gridOptions.data.forEach(function(row, index) {
            if (row.file === $localStorage.ContentTrackerFile) {
              $scope.gridApi.selection.selectRow($scope.gridOptions.data[index]);
            }
          });
        }, 100);
      });

  $scope.deleteRow = function(row) {
    var index = $scope.gridOptions.data.indexOf(row.entity);
    $scope.gridOptions.data.splice(index, 1);
    $localStorage.ContentTrackerFile = '';
  };

  $scope.navigateToTestPage = function(row) {
    var index = $scope.gridOptions.data.indexOf(row.entity);
    if(index > 0) {
      $scope.gridApi.selection.selectRow($scope.gridOptions.data[index]);
    }

    $localStorage.ContentTrackerFile = row.entity.file;
    //TODO : call the menu creation method;
  };

  $scope.gridOptions.onRegisterApi = function(gridApi){
    $scope.gridApi = gridApi;

    gridApi.selection.on.rowSelectionChanged($scope,function(row){
      $localStorage.ContentTrackerFile = row.entity.file;
    });
  };
}]);

